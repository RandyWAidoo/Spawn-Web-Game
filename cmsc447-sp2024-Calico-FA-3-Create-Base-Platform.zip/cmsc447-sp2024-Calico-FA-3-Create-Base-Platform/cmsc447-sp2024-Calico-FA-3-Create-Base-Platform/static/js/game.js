class MyScene extends Phaser.Scene {
    
    constructor(map_math) {
        super({ key: 'MyScene' });
        this.map_path = map_math;
    }

    preload() {

        this.load.image('tiles', 'assets/Icons/BlackSquarePNG.png');
        this.load.image('coins', 'assets/Icons/CoinPNG.png');
        this.add.image(100, 100, 'coins');
        this.load.image('enemies', 'assets/Icons/EnemyPNG.png');
        this.load.image('walls', 'assets/Icons/WallPNG.png');

        console.log("This is the map_path: ", this.map_path);
        this.load.tilemapCSV({
            key: 'map',
            url: '07a5152745c247d4a46d80a4daf0a2c2.csv'
        });

        console.log("Test: ", typeof(this.load.tileMapCSV));
        
        console.log(this.load.tileMapCSV);

    }

    create() {

        const map = this.make.tilemap({key: 'map', tileWidth: 32, tileHeight: 32});
        console.log(map);
        const tileset = map.addTilesetImage('coins', null, 32, 32, 1, 2);
        const layer = map.createLayer(0, tileset, 0, 0);

        const player = this.add.image(32 + 16, 32 + 16, 'tiles');

        //  Left
        this.input.keyboard.on('keydown-A', event =>
        {
            const tile = layer.getTileAtWorldXY(player.x - 32, player.y, true);
            if (tile.index === 2)
            {
                //  Blocked, we can't move
                console.log("Blocked, movement not allowed");
            }
            else
            {
                player.x -= 32;
                player.angle = 180;
            }

        });

        //  Right
        this.input.keyboard.on('keydown-D', event =>
        {

            const tile = layer.getTileAtWorldXY(player.x + 32, player.y, true);

            if (tile.index === 2)
            {
                //  Blocked, we can't move
                console.log("Blocked, movement not allowed");
            }
            else
            {
                player.x += 32;
                player.angle = 0;
            }

        });

        //  Up
        this.input.keyboard.on('keydown-W', event =>
        {

            const tile = layer.getTileAtWorldXY(player.x, player.y - 32, true);

            if (tile.index === 2)
            {
                //  Blocked, we can't move
                console.log("Blocked, movement not allowed");
            }
            else
            {
                player.y -= 32;
                player.angle = -90;
            }

        });

        //  Down
        this.input.keyboard.on('keydown-S', event =>
        {

            const tile = layer.getTileAtWorldXY(player.x, player.y + 32, true);

            if (tile.index === 2)
            {
                //  Blocked, we can't move
                console.log("Blocked, movement not allowed");
            }
            else
            {
                player.y += 32;
                player.angle = 90;
            }

        });

        this.add.text(8, 8, 'Move with WASD', {
            fontSize: '18px',
            fill: '#ffffff',
            backgroundColor: '#000000'
        });

    }

    update() {
        // Your update logic here
        //This is where I'd update points under certain conditions
        //This function runs every single second
        //console.log("Running");
    }

}

// Initialize Phaser game
const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    scene: MyScene
};

const game = new Phaser.Game(config);
const player_one = null;
const lvl_one_pts = 50;
const lvl_two_pts = 100;
const lvl_three_pts = 150;
const lvl_four_pts = 200;

function run_game(map_path){

    let path = map_path.substr(-36);
    //console.log("mapPath: ", path);
    map_path = path;
    fetch(map_path, { method: "HEAD" }) 
    .then(response => { 
        if (response.ok) { 
            //When I run this, sometimes I get s[?] as the two beginning characters of the map_path
            //in the console, but it still says it exists
            console.log("Map_path file exists: ", map_path); 
        } else { 
            console.log("Map_path file does not exist"); 
        } 
    }) 
    .catch(error => { 
        console.log("An error occurred: ", error); 
    }); 
    //console.log("New map path: ", map_path);
    //map_path = "25f7145064364cbaa47371e14456c60e.csv";
    game.scene.add('MyScene', new MyScene(map_path));
    game.scene.start('MyScene');

    //player_one = new Player("Z", 0, 0, false, true);

    //Copy phaser behaviour to read
    //0s are black squares
    //1s, 2s and 3s are different version of cells
    
    //0 for walls
    //1 is free
    //2 is a coin
    //3 is an enemy

    //cell_val_sets

    //make sure fetch command is separate from my code
    //just call fetch with parameters

    //Go on phaser thing, copy what they have, reorganize it

}

function player_movement(){



}


function apply_stat_change(){



}

function level_complete(){

    //Update DB and let them know which level was completed
    //Go back to

}


function player_lost(){



}

function restart(){



}

class Character{

    constructor(name, points, on_level, is_enemy, alive){
        this.name = name;
        this.points = points;
        this.on_level = on_level;
        this.is_enemy = is_enemy;
        this.alive = alive;
    }

    ChangePoints(change){
        this.points += change
    }

    ChangeLevel(new_level){
        this.on_level = new_level;
    }

    GetName(){ //Returns true if player collided with an enemy
        return this.name;
    }

    GetPoints(){ //Returns true if player collided with an enemy
        return this.points;
    }

    OnLevel(){ //Returns true if player collided with an enemy
        return this.on_level;
    }   

    IsEnemy(){ //Returns true if player collided with an enemy
        return this.enemy;
    }

    IsAlive(){
        return this.alive;
    }
}